from django.shortcuts import render

# Create your views here.
from rest_framework import permissions
from rest_framework.generics import CreateAPIView
from django.contrib.auth import get_user_model # If used custom user model

from rest_framework.views import  APIView
from rest_framework.response import Response
from .models import User, PhoneOTP
from rest_auth.registration.views import RegisterView
from  django.shortcuts import get_object_or_404
import random

from .serializer import CreateUserSerializer ,CustomRegisterSerializer

class ValidatePhoneSendOTP(APIView):
    def post(self,request,*args,**kwargs):
        phone_number =request.data.get('phone')
        if phone_number:
            phone = str(phone_number)
            user = User.objects.filter(phone__iexact= phone)
            if user.exists():
                return Response({
                    'status': False,
                    'detail':'phone number already exist'
                })
            else:
                key= send_otp(phone)
                if key:
                    old = PhoneOTP.objects.filter(phone__iexact=phone)
                    if old.exists():
                        old = old.first()
                        count = old.count
                        if count > 10:
                            return Response({
                                'status': False,
                                'detail': 'sending otp error, Limit exceeded contact customer support'
                            })
                        old.count = count + 1
                        old.save()
                        print(key)
                        print('count increases', count)
                        return Response({
                            'status': True,
                            'detail' : 'OPT sent successfully'
                        })
                    else:
                        PhoneOTP.objects.create(
                            phone =phone,
                            otp= key,
                        )
                        print(key)
                        return Response({
                            'status': True,
                            'detail': 'done otp sent'
                        })
                else:
                    return Response({
                        'status': False,
                        'detail': 'sending otp error'
                    })


        else:
            return Response({
                'status':False,
                'detail':'phone number is not given in post request'
            })



class ValidateOTP(APIView):
    """
    if you have received otp , post a request with phone and that otp and you will be redirected to set the password
    """
    def post(self, request , *args, **kwargs):
        phone = request.data.get('phone', False)
        otp_sent = request.data.get('otp',False)

        if phone and otp_sent:
            old = PhoneOTP.objects.filter(phone__iexact=phone)
            if old.exists():
                old = old.first()
                otp = old.otp
                if str(otp_sent) == str(otp):
                    old.validate = True
                    old.save()
                    return Response({
                        'status': True,
                        'detail': 'OTP matched please  proceed ofr registration '
                    })
                else:
                    return Response({
                        'status': False,
                        'detail': 'OTP INCORRECT'
                    })

            else:
                return Response({
                    'status': False,
                    'detail': 'First proceed via sending otp request'
                })

        else:
            return Response({
                'status': False,
                'detail': 'Please provide phone and otp for validation'
            })


class Register(APIView):

    def post(self, request, *args, **kwargs):
        phone = request.data.get('phone', False)
        password = request.data.get('password', False)
        if phone and password:
            temp_data = {
                'phone': phone,
                'password':password
                        }
            serializers = CreateUserSerializer(data=temp_data)
            serializers.is_valid(raise_exception=True)
            user = serializers.save()
            user.set_unusable_password()
            return Response({
                "hi": "done"
            })

        #     old = PhoneOTP.objects.filter(phone__iexact=phone)
        #     if old.exists():
        #         old = old.first()
        #         validated = old.validate
        #         if validated:
        #             temp_data={
        #                 'phone': phone,
        #                 'password':password
        #             }
        #             serializers = CreateUserSerializer(data=temp_data)
        #             serializers.is_valid(raise_exception= True)
        #             user = serializers.save()
        #             old.delete()
        #             return Response({
        #                 'status': True,
        #                 'detail': 'Account is  created '
        #             })
        #         else:
        #             return Response({
        #                 'status': False,
        #                 'detail': 'OTP havent verified first , verify that step (otp)'
        #             })
        #     else:
        #         return Response({
        #             'status': False,
        #             'detail': 'phone number is not sent check'
        #         })
        # else:
        #     return Response({
        #         'status': False,
        #         'detail' : 'phone and password are not sent'
        #     })





class CustomRegisterView(RegisterView):
    serializer_class = CustomRegisterSerializer




class CreateUserView(CreateAPIView):

    model = get_user_model()
    permission_classes = [
        permissions.AllowAny # Or anon users can't register
    ]
    serializer_class = CreateUserSerializer





def send_otp(phone):
    if phone:
        key = random.randint(999, 9999)
        return key
    else:
        return False